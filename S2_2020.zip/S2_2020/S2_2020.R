
### Título: Sesión 2
### Autor: Manuel Toral
### Fecha: 28 de marzo

### Objetivo: La alumna aprenderá la sintexis básica del tidyverse
###   con su propia lectura y manipulación de base de datos


### Bibliotecas:

library(tidyverse)
library(stringr)


### Bases

### Vamos a usar tres bases:

## Datos de películas en IMDB
### Base de obtenida por Datos de Miércoles: https://github.com/cienciadedatos/datos-de-miercoles

imdb <- readr::read_csv("https://raw.githubusercontent.com/cienciadedatos/datos-de-miercoles/master/datos/2020/2020-02-19/ranking_imdb.csv")

### La base de conflictos armados de ACLED (https://acleddata.com/data-export-tool/)

acled <- readr::read_csv("1_Datos/2010-01-01-2020-03-21.csv")

### Falta la base de películas de Netflix, ¿cómo la leerías?









##################### Las operaciones básicas de dplyr

# Seleccionar

# Ordenar

# Filtrar

# Mutar

# Agrupar y sumarizar






