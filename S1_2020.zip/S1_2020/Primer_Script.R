

### Título: Mi primer script
### Fecha: 21 de marzo de 2020 (Natalicio del Benemérito de las Américas)
### Objetivo: Concocer algunas reglas de sintaxis y de buenas prácticas para la redacción de código


# Paso 1: Conocer a mi público

## ¿A quién le voy a escribir este código? La respuesta siempre es: a mí misma.
## Siempre que escriban deben de pensar en que su yo del futuro tiene que ver esto y gustarle.


# Paso 2: Los básicos

## "Correr" un código es muy simple: sólo tienes que colocar el cursor en una línea 
## y apretar CTRL + ENTER o CMD + ENTER. Si hay un (#) antes, esto es un mero comentario y no pasará nada.

# Prueba corriento lo siguiente

2 + 2

6 + 5

8 + 12^4 + sqrt(4)


# Paso 3: Crear objetos

## Objetos de números

nombre <- 2

nombres <-  c(2, 8, 5)


## Objetos de letras

nombre <- "Miriam"

nombres <-  c("Miriam", "Alejandra", "Jesusa")


## Objetos lógicos

nombre <- TRUE

nombres <-  c(TRUE, FALSE, TRUE)


############## Prueba crear un objeto de cada tipo:


# Paso 4: Cuando Base R no es suficiente, se necesitan la "bibliotecas". 

## Hay varios comandos que sólo funcionan con ciertas librerías. Prueba correr este código.

avengers

## Antes de usarlas, es necesario instalarlas. Por ejemplo, prueba instalando fivethirtyeigh

install.packages("fivethirtyeight") #Instalo

library(fivethirtyeight) #Llamo

avengers # Ejecuto


#################### Prueba instalar estos paquetes: tidyverse, janitor, wesanderson



# Paso 5: LaS Sintaxis de R

## R tiene tres sintaxis principales: Base R (signo de dólar), la del tydyverse y la flamante data.table. 

avengers <- avengers

## Con Base R ($)

avengers$name_alias

## Con tidyverse (dplyr)

avengers %>% 
  select(name_alias)
